/************************************************************************
 Programmer: Kofi Frimpong
 Class: CptS 121; Lab Section 1
 Programming Assignment: Programming Assignment 3
 Date: 9/22/20

 Description: This program processes numbers, orresponding to
				student records read in from a file,
				and writes the required results to an
				output file (see main ( )).

************************************************************************/


#ifndef VALUE
#define VALUE

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h> /* Header file for scanf, printf */
#include <stdlib.h>
#include <math.h> /* Header file for pow(), sqrt() */
#include <time.h>

/* List the function prototypes for the program */\
/* The descriptions for each of the functions can be seen in a comment block in the function.c file
above each function definition */

void start();
void load_screen();
void print_game_rules(void); 
double get_bank_balance(void); 
double get_wager_amount(void);
int check_wager_amount(double wager, double balance);
int roll_die(void); 
int calculate_sum_dice(int die1_value, int die2_value); 
int is_win_loss_or_point(int sum_dice); 
int is_point_loss_or_neither(int sum_dice, int point_value); 
double adjust_bank_balance(double bank_balance, double wager_amount, int add_or_subtract); 
void chatter_messages(int number_rolls); 

#endif // !VALUE