/************************************************************************
 Programmer: Kofi Frimpong
 Class: CptS 121; Lab Section 1
 Programming Assignment: Programming Assignment 3
 Date: 9/22/20

 Description: This program processes numbers, orresponding to
				student records read in from a file,
				and writes the required results to an
				output file (see main ( )).

************************************************************************/

// Header File for scanf, printf, and functions
#include "functions.h"

/*************************************************************
* Function: start                                 *
* Date Created:  10/12/20                                    *
* Date Last Modified:   10/12/20                             *
* Description: runs the game/ loading screen                     *
* Input parameters: void                                     *
* Returns: Double void                                       *
* Preconditions:   void                                      *
* Postconditions: void                                       *
*************************************************************/
void start(void) {
	double time = 0, runtime = 7;
	char play = 'N';
	printf("Would you like to play?(Y/N):");
	scanf(" %c", &play);
	system("cls");

	if (play == 'N') {
		system("cls");
	}
	else {
		printf("Loading....\n");
		load_screen();
		system("cls");
		print_game_rules();
	}
	system("cls");
}
/*************************************************************
* Function: load screen                                 *
* Date Created:  10/12/20                                    *
* Date Last Modified:   10/12/20                             *
* Description: waits until 7 seconds have passed until it runs the code                     *
* Input parameters: void                                     *
* Returns: Double void                                       *
* Preconditions:   void                                      *
* Postconditions: void                                       *
*************************************************************/
void load_screen() {
	
	//Partially from the internet especially stack overflow
	double time = 0.0;
	clock_t begin = clock();
	while ((double)time / CLOCKS_PER_SEC < 7) {
		clock_t end = clock();
		time = (double)(end + begin);
	}
	

}
/*************************************************************
* Function: print_game_rules                                 *
* Date Created:  10/12/20                                    *
* Date Last Modified:   10/12/20                             *
* Description: prints out the game rules                     *
* Input parameters: void                                     *
* Returns: Double void                                       *
* Preconditions:   void                                      *
* Postconditions: void                                       *
*************************************************************/
void print_game_rules(void) 
{
	printf("Welcome to PA4 by Kofi Frimpong!!\nToday you'll be playing a game of craps which I programmed.\nThe Rules of the Game are listed below\n");
	printf("You will roll 2 virtual six sided Dix.\n" );
	printf("If the sum of the dix is 7 or 11 on the first throw, you win.\nIf the sum is 2, 3, or 12 on the first throw \(called \"craps\")," );
	printf("you lose.\nIf the sum is 4, 5, 6, 8, 9, or 10 ");
	printf("on the first throw, then the sum becomes your points.\n");
	printf("To win, you must continue rolling the dice until you ");
	printf("make your point.\nThe player loses by rolling a 7 before making the point.\n");
	printf("--------------------------------------------------------------------------\n");
	system("pause");
}
/*************************************************************
* Function: get_bank_balance                              *
* Date Created:  10/12/20                                    *
* Date Last Modified:   10/12/20                             *
* Description: get a balance from the user                    *
* Input parameters: void                                   *
* Returns: Double                                      *
* Preconditions: void                                     *
* Postconditions: returns a balance                                      *
*************************************************************/
double get_bank_balance(void)
{	
	double balance = 0.0;
	printf("Enter a Account Balance:$");
	scanf("%lf", &balance);
	return balance;
}
/*************************************************************
* Function:   get wager amount                           *
* Date Created:  10/12/20                                    *
* Date Last Modified:   10/12/20                             *
* Description:  get a wager amount from the user                   *
* Input parameters: void                                   *
* Returns: Double                                      *
* Preconditions:  void                                    *
* Postconditions: returns a wager amount                                      *
*************************************************************/
double get_wager_amount(void) {
	double wager = 0.0;
	printf("Enter a Wager Amount:$");
	scanf("%lf", &wager);
	return wager;
}
/*************************************************************
* Function: check wager amount                            *
* Date Created:  10/12/20                                    *
* Date Last Modified:   10/12/20                             *
* Description: checks if wager exceeds balance                    *
* Input parameters: wager balance                                   *
* Returns: int                                      *
* Preconditions: wager balance                                     *
* Postconditions: value 1 or 0                                      *
*************************************************************/
int check_wager_amount(double wager, double balance) {
	printf("Processing you Wager......\n");
	int value = 0;
	if (wager <= balance) {
		value = 1;
		system("cls");
		printf("Wager was successfully processed.\n\n");
		system("pause");
	}
	else {
		system("cls");
		printf("Value Entered was greater than account balance re-enter a Wager.\n");
		system("pause");
	}
	
	return value;
}
/*************************************************************
* Function: roll die                                        *
* Date Created:  10/12/20                                   *
* Date Last Modified:   10/12/20                            *
* Description: gets a value between 1 and 6             *
* Input parameters: void                                    *
* Returns: dix roll between 1 and 6                         *
* Preconditions: void                                       *
* Postconditions: value between 1 and 6                     *
*************************************************************/
int roll_die(void) {
	return rand() % 6 + 1;
}
/*************************************************************
* Function:  calculate sum of dice                                      *
* Date Created:  10/12/20                                   *
* Date Last Modified:   10/12/20                            *
* Description:  sums the two dice rolls            *
* Input parameters: die one and die two                                    *
* Returns: sum of dix                       *
* Preconditions: value between 1 and 6                                      *
* Postconditions:  sum                    *
*************************************************************/
int calculate_sum_dice(int die1_value, int die2_value) {
	return die1_value + die2_value;
}
/*************************************************************
* Function: is win loss or points                                       *
* Date Created:  10/12/20                                   *
* Date Last Modified:   10/12/20                            *
* Description: reads whether or not the game is lost or is won             *
* Input parameters: sum of dice                                   *
* Returns:    win loss or point (1,0,-1)                    *
* Preconditions: value must be valid integers                                     *
* Postconditions: 1,0,-1 outputed                     *
*************************************************************/
int is_win_loss_or_point(int sum_dice) {
	int value = -1;
	if (sum_dice == 7 || sum_dice == 11) {
		//Win
		value = 1;
		printf("Congratulations You Win!!\n");
		printf("----------------------------------\n");
	}
	else if (sum_dice == 2 || sum_dice == 3 || sum_dice == 12) {
		//Lose
		value = 0;
		printf("Unfortunately You Lose\n");
		printf("----------------------------------\n");
	}
	return value;
}
/*************************************************************
* Function:                                        *
* Date Created:  10/12/20                                   *
* Date Last Modified:   10/12/20                            *
* Description:              *
* Input parameters: void                                    *
* Returns:                        *
* Preconditions: void                                       *
* Postconditions:                      *
*************************************************************/
int is_point_loss_or_neither(int sum_dice, int point_value) {
	int value = -1;
	if (sum_dice == point_value) {
		//Sum = Points
		value = 1;
		printf("Congratulations the sum of the Die matched the points you Win!!\n");
	}
	else if (sum_dice == 7) {
		//Lose
		value = 0;
		printf("Unfortunately You Lose\n");
	}
	return value;
}
/*************************************************************
* Function: adjust bank balance                                       *
* Date Created:  10/12/20                                   *
* Date Last Modified:   10/12/20                            *
* Description:adds or subtracts bank values              *
* Input parameters: bank balance ager add/ subtract                                 *
* Returns: new balance                    *
* Preconditions: void                                       *
* Postconditions:                      *
*************************************************************/
double adjust_bank_balance(double bank_balance, double wager_amount, int add_or_subtract) {
	double value = 0;
	int choice = rand() % 3 + 1;
		if (add_or_subtract == 1) {
		value = bank_balance + wager_amount;
		switch (choice) {
		case(1):printf("Your so close to being a Millionare. New Balance = $%.2lf\n", value);
			break;
		case(2):printf("Congratulations more money for you. New Balance = $%.2lf\n", value);
			break;
		case(3):printf("I dont have infinity money you know. New Balance = $%.2lf\n", value);
			break;
		}
		}
		else {
			value = bank_balance - wager_amount;
			switch (choice) {
			case(1):printf("Whoops Looks like you went a little crazy there, didnt you. New Balance = $%.2lf\n", value);
				break;
			case(2):printf("Better Luck Next Time. New Balance = $%.2lf\n", value);
				break;
			case(3):printf("You Kind of Suck at this game. New Balance = $%.2lf\n", value);
				break;
			}
		}
		return value;
}
/*************************************************************
* Function: chatter messages                                 *
* Date Created:  10/12/20                                    *
* Date Last Modified: 10/12/20                               *
* Description: chatter messages                              *
* Input parameters: rolls win loss neither initial balance current balance       *
* Returns: void                                              *
* Preconditions: rools win loss bank balance befo and after  *
* Postconditions:  void                                      *
*************************************************************/
void chatter_messages(int number_rolls) {
	int choice = rand() % 3 + 1;
	if (number_rolls <= 2) {
		switch (choice) {
		case(1):printf("Your luck is not on point I can tell.\n");
			break;
		case(2):printf("You should definetly roll again.\n");
			break;
		case(3):printf("Lets see what happens.\n");
			break;
		}
	}
	else if (number_rolls <= 4) {
		switch (choice) {
		case(1):printf("Bruh how many times have you rolled!\n");
			break;
		case(2):printf("Good Luck Chances aren't looking good.\n");
			break;
		case(3):printf("I got faith in you.\n");
			break;
		}
	}
	else if (number_rolls <= 8) {
		switch (choice) {
		case(1):printf("Yaa nah your luck is down terrible.\n");
			break;
		case(2):printf(".....\n");
			break;
		case(3):printf("Thats tuff ngl.\n");
			break;
		}
	}
}