/************************************************************************
 Programmer: Kofi Frimpong
 Class: CptS 121; Lab Section 1
 Programming Assignment: Programming Assignment 4
 Date: 10/12/20

 Description: This program is the game Craps

************************************************************************/





// inputting information from function.h 
#include "functions.h"


//Main
int main(void) 
{
	//Variable Initialization
	srand(time(NULL));
	double balance = 0.0, wager = 0.0, cbalance = 0.0;
	int r1, r2, sum, winloss = 0, pointValue = 0, wbc = 0, rolls = 0;
	char roll = 'N', play = 'N';

	//Function Initialization
	start();
	balance = get_bank_balance();
	cbalance = balance;
	wager = get_wager_amount();
	wbc = check_wager_amount(wager, balance);
	r1 = roll_die();
	r2 = roll_die();
	rolls++;
	printf("Die one: %d\nDie two: %d\n", r1, r2);
	sum = calculate_sum_dice(r1, r2);
	printf("Sum: %d\n", sum);
	winloss = is_win_loss_or_point(sum);


	//Win Statements and Retry
	while (winloss == -1) {
		chatter_messages(rolls);
		printf("Would You like to Roll Again?(Y/N):");
		scanf(" %c", &roll);
		if (roll == 'Y') {
			system("cls");
			pointValue = sum;
			r1 = roll_die();
			r2 = roll_die();
			rolls++;
			printf("New Dix Roll\nDie one: %d\nDie two: %d\n", r1, r2);
			sum = calculate_sum_dice(r1, r2);
			printf("Sum: %d\n", sum);
			printf("Point Value: %d\n", pointValue);
			winloss = is_point_loss_or_neither(sum, pointValue);
			if (winloss != -1) {
				break;
			}
		}
		else {
			break;
		}
	}
	if (winloss == 1) {
		//won
		cbalance = adjust_bank_balance(balance, wager, 1);
		
	}
	else if (winloss == 0) {
		//Lose
		printf("Balance: %d\n", balance);
		cbalance = adjust_bank_balance(balance, wager, 0);

	}
	printf("Would You Like to Play Again?(Y/N): ");
	scanf(" %c", &play);
	if (play == 'Y') {
		system("cls");
		main();
	}
	return 0;

}